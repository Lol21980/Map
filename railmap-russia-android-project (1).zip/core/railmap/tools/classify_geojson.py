"""Добавляет классификацию электрификации к линиям из `osmium export`.

Пример подготовки региона (нужны osmium-tool и выгрузка с законного источника, ODbL):
  osmium tags-filter region.osm.pbf w/railway=rail,light_rail,narrow_gauge -o rail.osm.pbf
  osmium export rail.osm.pbf -f geojsonseq -x print_record_separator=false -o rail.geojsonl
  python classify_geojson.py rail.geojsonl rail_classified.geojsonl --stats stats.json
"""
from __future__ import annotations

import argparse
import json
import math
import sys

from electrification import classify

R_KM = 6371.0088


def _seg_km(a, b) -> float:
    la1, la2 = math.radians(a[1]), math.radians(b[1])
    dlon = math.radians(b[0] - a[0])
    h = (math.sin((la2 - la1) / 2) ** 2
         + math.cos(la1) * math.cos(la2) * math.sin(dlon / 2) ** 2)
    return 2 * R_KM * math.asin(math.sqrt(h))


def geometry_length_km(geom) -> float:
    if not geom:
        return 0.0
    t, c = geom.get("type"), geom.get("coordinates") or []
    lines = [c] if t == "LineString" else c if t == "MultiLineString" else []
    return sum(_seg_km(l[i], l[i + 1]) for l in lines for i in range(len(l) - 1))


def process(src: str, dst: str) -> dict:
    stats = {"segments": 0, "length_km": 0.0, "skipped_invalid": 0,
             "by_category": {}, "by_status": {},
             "disclaimer": "Статистика описывает полноту данных OSM в выгрузке, "
                           "а не фактическую электрификацию сети РЖД."}
    with open(src, encoding="utf-8") as fin, open(dst, "w", encoding="utf-8") as fout:
        for line in fin:
            line = line.strip().lstrip("\x1e").strip()
            if not line:
                continue
            try:
                feat = json.loads(line)
            except json.JSONDecodeError:
                stats["skipped_invalid"] += 1
                continue
            props = feat.setdefault("properties", {}) or {}
            feat["properties"] = props
            res = classify(props)
            props["elec"] = res.to_dict()
            fout.write(json.dumps(feat, ensure_ascii=False) + "\n")

            km = geometry_length_km(feat.get("geometry"))
            stats["segments"] += 1
            stats["length_km"] += km
            for key, val in (("by_category", res.category.value), ("by_status", res.status.value)):
                b = stats[key].setdefault(val, {"segments": 0, "length_km": 0.0})
                b["segments"] += 1
                b["length_km"] += km
    stats["length_km"] = round(stats["length_km"], 3)
    for key in ("by_category", "by_status"):
        for b in stats[key].values():
            b["length_km"] = round(b["length_km"], 3)
    return stats


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--stats")
    a = ap.parse_args()
    s = process(a.src, a.dst)
    out = json.dumps(s, ensure_ascii=False, indent=2)
    if a.stats:
        open(a.stats, "w", encoding="utf-8").write(out)
    print(out, file=sys.stderr)
