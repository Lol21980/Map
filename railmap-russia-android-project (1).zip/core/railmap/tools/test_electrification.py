import json, os, tempfile, unittest
from electrification import classify, parse_voltages, Category as C, Status as S
from classify_geojson import process, geometry_length_km


class Classify(unittest.TestCase):
    def t(self, **tags):
        return classify(tags)

    def test_dc3000_confirmed(self):
        r = self.t(electrified="contact_line", voltage="3000", frequency="0")
        self.assertEqual((r.category, r.status), (C.DC_3000, S.CONFIRMED))

    def test_dc3000_without_frequency_is_inferred(self):
        r = self.t(electrified="contact_line", voltage="3000")
        self.assertEqual((r.category, r.status), (C.DC_3000, S.INFERRED))

    def test_ac25_confirmed(self):
        r = self.t(electrified="contact_line", voltage="25000", frequency="50")
        self.assertEqual((r.category, r.status), (C.AC_25KV_50HZ, S.CONFIRMED))

    def test_ac25_without_frequency_is_inferred(self):
        r = self.t(electrified="contact_line", voltage="25000")
        self.assertEqual((r.category, r.status), (C.AC_25KV_50HZ, S.INFERRED))

    def test_electrified_without_voltage_is_never_3000(self):
        r = self.t(electrified="contact_line")
        self.assertEqual((r.category, r.status), (C.UNKNOWN, S.INCOMPLETE))

    def test_no_tags_is_no_data_not_unelectrified(self):
        r = self.t(railway="rail")
        self.assertEqual((r.category, r.status), (C.UNKNOWN, S.NO_DATA))

    def test_electrified_no(self):
        self.assertEqual(self.t(electrified="no").category, C.NOT_ELECTRIFIED)

    def test_no_with_voltage_conflict(self):
        r = self.t(electrified="no", voltage="3000")
        self.assertEqual((r.category, r.status), (C.CONFLICT, S.CONFLICT))

    def test_3000_with_50hz_conflict(self):
        r = self.t(electrified="contact_line", voltage="3000", frequency="50")
        self.assertEqual(r.category, C.CONFLICT)

    def test_25kv_with_dc_conflict(self):
        r = self.t(electrified="contact_line", voltage="25000", frequency="0")
        self.assertEqual(r.category, C.CONFLICT)

    def test_multi_system(self):
        r = self.t(electrified="contact_line", voltage="3000;25000", frequency="0;50")
        self.assertEqual((r.category, r.status, len(r.systems)), (C.OTHER_SYSTEM, S.CONFIRMED, 2))

    def test_dc_other(self):
        r = self.t(electrified="contact_line", voltage="1500", frequency="0")
        self.assertEqual(r.category, C.DC_OTHER)

    def test_unparseable_voltage(self):
        r = self.t(electrified="contact_line", voltage="abc")
        self.assertEqual((r.category, r.status), (C.UNKNOWN, S.INCOMPLETE))

    def test_voltage_only_no_electrified_tag(self):
        r = self.t(voltage="3000", frequency="0")
        self.assertEqual((r.category, r.status), (C.DC_3000, S.INFERRED))

    def test_unknown_current_type_is_incomplete(self):
        r = self.t(electrified="contact_line", voltage="1000")
        self.assertEqual((r.category, r.status), (C.OTHER_SYSTEM, S.INCOMPLETE))

    def test_unpaired_frequencies_incomplete(self):
        r = self.t(electrified="contact_line", voltage="25000", frequency="50;0")
        self.assertEqual(r.status, S.INCOMPLETE)

    def test_unknown_electrified_value(self):
        r = self.t(electrified="construction")
        self.assertEqual((r.category, r.status), (C.UNKNOWN, S.INCOMPLETE))

    def test_voltage_formats(self):
        for raw in ("3000", "3 000", "3kV", "3 kV", "3000 V", "3000,0"):
            self.assertEqual(parse_voltages(raw), ([3000], False), raw)


class Pipeline(unittest.TestCase):
    def test_length_one_degree_lat(self):
        km = geometry_length_km({"type": "LineString", "coordinates": [[30, 50], [30, 51]]})
        self.assertAlmostEqual(km, 111.195, delta=0.05)

    def test_end_to_end_with_record_separators(self):
        feats = [
            {"type": "Feature", "properties": {"railway": "rail", "electrified": "contact_line",
             "voltage": "3000", "frequency": "0"},
             "geometry": {"type": "LineString", "coordinates": [[30, 50], [30, 51]]}},
            {"type": "Feature", "properties": {"railway": "rail"},
             "geometry": {"type": "LineString", "coordinates": [[31, 50], [31, 51]]}},
        ]
        with tempfile.TemporaryDirectory() as d:
            src, dst = os.path.join(d, "a.jsonl"), os.path.join(d, "b.jsonl")
            with open(src, "w", encoding="utf-8") as f:
                f.write("\x1e" + json.dumps(feats[0]) + "\n\x1e" + json.dumps(feats[1]) + "\nBROKEN{\n")
            s = process(src, dst)
            self.assertEqual((s["segments"], s["skipped_invalid"]), (2, 1))
            self.assertEqual(s["by_category"]["dc_3000"]["segments"], 1)
            self.assertEqual(s["by_category"]["unknown"]["segments"], 1)
            first = json.loads(open(dst, encoding="utf-8").readline())
            self.assertEqual(first["properties"]["elec"]["category"], "dc_3000")


if __name__ == "__main__":
    unittest.main()
