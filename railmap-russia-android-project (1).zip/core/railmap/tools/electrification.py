"""Классификация электрификации железных дорог по тегам OpenStreetMap.

Правила (см. README.md, раздел «Электрификация»):
  * Не выдумываем напряжение: если электрификация есть, а voltage нет -> UNKNOWN.
  * Отсутствие тега electrified != «не электрифицировано» -> UNKNOWN / NO_DATA.
  * Противоречия (напр. 3000 В и 50 Гц) -> CONFLICT («требует проверки»).
  * Статусы различают подтверждённые, выведенные и неполные сведения.
Это данные карты, а не состояние контактной сети в реальном времени.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping, Optional


class Category(str, Enum):
    DC_3000 = "dc_3000"              # постоянный ток 3000 В
    DC_OTHER = "dc_other"            # постоянный ток, другое напряжение
    AC_25KV_50HZ = "ac_25kv_50hz"    # переменный ток 25 кВ, 50 Гц
    OTHER_SYSTEM = "other_system"    # другие/несколько систем
    NOT_ELECTRIFIED = "not_electrified"
    UNKNOWN = "unknown"              # «Нет данных» / неполные данные
    CONFLICT = "conflict"            # противоречия, требует проверки


class Status(str, Enum):
    CONFIRMED = "confirmed"    # напряжение и частота указаны и согласуются
    INFERRED = "inferred"      # род тока выведен по напряжению / нет части тегов
    INCOMPLETE = "incomplete"  # данные неполны или не разобраны
    CONFLICT = "conflict"
    NO_DATA = "no_data"


# Допущения для случая «частота не указана». Это приблизительный вывод (INFERRED).
INFERRED_DC_VOLTS = {600.0, 750.0, 825.0, 1500.0, 3000.0}
INFERRED_AC_VOLTS = {25000.0: 50.0}

CATENARY_OR_RAIL_VALUES = {"yes", "contact_line", "rail", "4th_rail",
                           "3rd_rail", "ground-level_power_supply"}

_VOLT_RE = re.compile(r"^(\d+(?:[.,]\d+)?)\s*(kv|v)?$", re.I)
_FREQ_RE = re.compile(r"^(\d+(?:[.,]\d+)?)\s*(hz)?$", re.I)


@dataclass
class System:
    voltage_v: Optional[float]
    frequency_hz: Optional[float]
    current: Optional[str]          # "DC" | "AC" | None
    current_inferred: bool
    category: Category
    conflict: bool = False


@dataclass
class Result:
    category: Category
    status: Status
    systems: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    supply: Optional[str] = None    # значение тега electrified

    def to_dict(self) -> dict:
        return {
            "category": self.category.value,
            "status": self.status.value,
            "voltage_v": [s.voltage_v for s in self.systems],
            "frequency_hz": [s.frequency_hz for s in self.systems],
            "notes": list(self.notes),
            "supply": self.supply,
        }


def _split(raw: str) -> list:
    return [p.strip() for p in raw.split(";") if p.strip()]


def _num(x: float):
    return int(x) if float(x).is_integer() else x


def parse_voltages(raw: str):
    """-> (значения в вольтах, были_ли_нераспознанные_части)."""
    vals, bad = [], False
    for part in _split(raw):
        part = re.sub(r"(?<=\d)[ \u00a0](?=\d)", "", part)  # «3 000» -> «3000»
        m = _VOLT_RE.match(part)
        if not m:
            bad = True
            continue
        v = float(m.group(1).replace(",", "."))
        if (m.group(2) or "").lower() == "kv":
            v *= 1000
        vals.append(_num(v))
    return vals, bad


def parse_frequencies(raw: str):
    vals, bad = [], False
    for part in _split(raw):
        m = _FREQ_RE.match(part)
        if not m:
            bad = True
            continue
        vals.append(_num(float(m.group(1).replace(",", "."))))
    return vals, bad


def classify_system(v: float, f: Optional[float]) -> System:
    inferred = False
    if f is not None:
        current = "DC" if f == 0 else "AC"
    elif v in INFERRED_DC_VOLTS:
        current, inferred = "DC", True
    elif v in INFERRED_AC_VOLTS:
        current, inferred = "AC", True
    else:
        current = None

    conflict = (v == 3000 and current == "AC") or (v == 25000 and current == "DC")
    if conflict:
        cat = Category.CONFLICT
    elif current == "DC":
        cat = Category.DC_3000 if v == 3000 else Category.DC_OTHER
    elif current == "AC" and v == 25000 and (f is None or f == 50):
        cat = Category.AC_25KV_50HZ
    else:
        cat = Category.OTHER_SYSTEM
    return System(v, f, current, inferred, cat, conflict)


def classify(tags: Mapping[str, str]) -> Result:
    el = (tags.get("electrified") or "").strip().lower()
    volt_raw = (tags.get("voltage") or "").strip()
    freq_raw = (tags.get("frequency") or "").strip()

    if el == "no":
        if volt_raw:
            return Result(Category.CONFLICT, Status.CONFLICT, supply=el,
                          notes=["electrified=no, но указано voltage — требует проверки"])
        return Result(Category.NOT_ELECTRIFIED, Status.CONFIRMED, supply=el,
                      notes=["По данным OSM; фактическое состояние не проверялось"])

    if not el and not volt_raw:
        return Result(Category.UNKNOWN, Status.NO_DATA, notes=["Нет данных"])

    if el and el not in CATENARY_OR_RAIL_VALUES:
        return Result(Category.UNKNOWN, Status.INCOMPLETE, supply=el,
                      notes=[f"Неизвестное значение electrified={el}"])

    volts, bad_v = parse_voltages(volt_raw)
    if not volts:
        notes = ["Электрификация указана, напряжение неизвестно"]
        if bad_v:
            notes.append(f"Не удалось разобрать voltage={volt_raw!r}")
        return Result(Category.UNKNOWN, Status.INCOMPLETE, supply=el or None, notes=notes)

    freqs, bad_f = parse_frequencies(freq_raw)
    notes, unpaired = [], False
    if len(freqs) == len(volts):
        pairs = list(zip(volts, freqs))
    elif not freqs:
        pairs = [(v, None) for v in volts]
    else:
        pairs = [(v, None) for v in volts]
        unpaired = True
        notes.append("Частоты не удалось сопоставить с напряжениями")
    if bad_v:
        notes.append("Часть значений voltage не разобрана")
    if bad_f:
        notes.append("Часть значений frequency не разобрана")

    systems = [classify_system(v, f) for v, f in pairs]

    if any(s.conflict for s in systems):
        notes.append("Напряжение и род тока противоречат друг другу — требует проверки")
        return Result(Category.CONFLICT, Status.CONFLICT, systems, notes, el or None)

    cats = {s.category for s in systems}
    if len(cats) == 1:
        category = cats.pop()
    else:
        category = Category.OTHER_SYSTEM
        notes.append("Несколько систем электрификации")

    problems = bad_v or bad_f or unpaired or any(s.current is None for s in systems)
    if any(s.current is None for s in systems):
        notes.append("Род тока не определён")
    if problems:
        status = Status.INCOMPLETE
    elif any(s.frequency_hz is None for s in systems):
        status = Status.INFERRED
        notes.append("Частота не указана: род тока выведен по напряжению")
    else:
        status = Status.CONFIRMED

    if not el:
        notes.append("Тег electrified не указан (есть только voltage)")
        if status == Status.CONFIRMED:
            status = Status.INFERRED

    return Result(category, status, systems, notes, el or None)
